<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- Favicon-->
    <link rel="shortcut icon" href="{{ asset('customer/img/fav.png') }}">
    <!-- Author Meta -->
    <meta name="author" content="CodePixar">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>Anrimusthi Badminton Centre Kuningan</title>
    <!--
        CSS
        ============================================= -->
    <link rel="stylesheet" href="{{ asset('customer/css/linearicons.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/font-awesome.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/themify-icons.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/bootstrap.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/owl.carousel.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/nice-select.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/nouislider.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/ion.rangeSlider.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/ion.rangeSlider.skinFlat.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/magnific-popup.css') }}"/>
    <link rel="stylesheet" href="{{ asset('customer/css/main.css') }}"/>
</head>

<body>

    <!-- Start Header Area -->
    @include('layouts.particals.header')
    <!-- End Header Area -->

    @yield('content')

    <!-- start footer Area -->
    @include('layouts.particals.footer')
    <!-- End footer Area -->

    <script src="{{ asset('customer/js/vendor/jquery-2.2.4.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4"
     crossorigin="anonymous"></script>
    <script src="{{ asset('customer/js/vendor/bootstrap.min.js') }}"></script>
    <script src="{{ asset('customer/js/jquery.ajaxchimp.min.js') }}"></script>
    <script src="{{ asset('customer/js/jquery.nice-select.min.js') }}"></script>
    <script src="{{ asset('customer/js/jquery.sticky.js') }}"></script>
    <script src="{{ asset('customer/js/nouislider.min.js') }}"></script>
    <script src="{{ asset('customer/js/countdown.js') }}"></script>
    <script src="{{ asset('customer/js/jquery.magnific-popup.min.js') }}"></script>
    <script src="{{ asset('customer/js/owl.carousel.min.js') }}"></script>
    <!--gmaps Js-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
    <script src="{{ asset('customer/js/gmaps.min.js') }}"></script>
    <script src="{{ asset('customer/js/main.js') }}"></script>
    @yield('scripts')
</body>

</html>