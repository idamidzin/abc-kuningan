<div class="p-3 text-center">
    <span class="mr-2">&copy; 2020</span>
    <span class="mr-2">-</span>
    <span>Anrimusthi Badminton Centre Kuningan</span>
</div>
