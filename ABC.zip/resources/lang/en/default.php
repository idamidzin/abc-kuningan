<?php

return [

	'dashboard' => array(
		'WELCOME' => 'Welcome to Angle !',
	),
	'topbar' => array(
		'search' => array(
			'PLACEHOLDER' => 'Type and hit enter..',
		),
	),
	'sidebar' => array(
		'WELCOME' => 'Welcome',
		'heading' => array(
			'HEADER' => 'Main Navigation',
		),
		'nav' => array(
			'SINGLEVIEW' => 'Single View',
			'menu' => array(
				'MENU' => 'Menu',
				'SUBMENU' => 'Sub Menu',
			),
		),
	),

];
